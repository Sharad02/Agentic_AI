""" Stock Agent for Stock Analysis"""
from .agent import stock_agent