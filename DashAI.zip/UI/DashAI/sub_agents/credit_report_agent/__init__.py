""" Credit Report Agent for Credit Analysis"""

from .agent import credit_report_agent