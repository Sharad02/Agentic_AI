""" Mutual Fund Agent for Mutual Fund Analysis"""
from .agent import mf_agent