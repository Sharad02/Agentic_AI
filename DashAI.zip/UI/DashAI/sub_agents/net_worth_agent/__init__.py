""" Net Worth Agent for Net Worth Analysis"""

from .agent import net_worth_agent