"""DashAI - Financial coordinator: provide reasonable finance information """

from DashAI import agent
