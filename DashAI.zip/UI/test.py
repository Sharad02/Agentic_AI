import os
from typing import TypedDict
from google.cloud import aiplatform
from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools import FunctionTool

# === AUTH SETUP ===
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/workspaces/AgenticAI-Hackthon/src/UI/agentic-ai-466415-5a1005031578.json"
aiplatform.init(project="agentic-ai-466415", location="us-central1")

# === TOOL 1: Calculator ===
def basic_calculator(operation: str, a: float, b: float) -> float:
    """Performs basic arithmetic operations."""
        if operation == "add":
                return a + b
                    elif operation == "subtract":
                            return a - b
                                elif operation == "multiply":
                                        return a * b
                                            elif operation == "divide":
                                                    return a / b if b != 0 else float('inf')
                                                        else:
                                                                raise ValueError("Invalid operation.")

                                                                # The ADK automatically infers the schema and description from the function's
                                                                # docstrings and type hints.
                                                                calculator_tool = FunctionTool(func=basic_calculator)

                                                                # === TOOL 2: Adder ===
                                                                def adder(a: float, b: float) -> float:
                                                                    """A simple tool that only adds two numbers."""
                                                                        return a + b

                                                                        adder_tool = FunctionTool(func=adder)

                                                                        # === AGENTS ===
                                                                        basic_math_agent = LlmAgent(
                                                                            name="basic_math_agent",
                                                                                instructions="Use this agent for any kind of math operation like add, subtract, multiply, or divide.",
                                                                                    tools=[calculator_tool]
                                                                                    )

                                                                                    adder_agent = LlmAgent(
                                                                                        name="adder_agent",
                                                                                            instructions="Use this agent ONLY when the user asks specifically to add two numbers.",
                                                                                                tools=[adder_tool]
                                                                                                )

                                                                                                # === ROOT AGENT ===
                                                                                                # FIXED: The parent agent takes a list of 'tools', not 'agents'.
                                                                                                # The sub-agents (basic_math_agent, adder_agent) are treated as tools by the root_agent.
                                                                                                root_agent = LlmAgent(
                                                                                                    name="root_agent",
                                                                                                        instructions="You are a router. Based on the user's query, route the task to the correct agent.",
                                                                                                            tools=[basic_math_agent, adder_agent]
                                                                                                            )

                                                                                                            # === RUN ===
                                                                                                            runner = Runner(session_service=InMemorySessionService())
                                                                                                            runner.run(root_agent)